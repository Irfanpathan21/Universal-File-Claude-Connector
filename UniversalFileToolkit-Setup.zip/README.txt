Universal File Toolkit - Windows App

1. Double-click Setup.exe to install and configure.
2. Click 'Start Setup' to register desktop and start menu shortcuts.
3. Launch and search 'Universal File Toolkit' from Windows Search anytime.
